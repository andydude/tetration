#include "gxattr.h"

void gxattr_usage(int status);
void gxattr_usage(int status)
{
    printf("Usage:\n");
    printf("    gxattr -h\n");
    printf("    gxattr -L file\n");
    printf("    gxattr -G name file\n");
    printf("    gxattr -S name value file\n");
    printf("    gxattr -R name file\n");
    exit(status);
}

int
main(int argc, char ** argv)
{
	if (argc <= 1) {
	   gxattr_usage(EXIT_FAILURE);
    }
    if (!strcmp(argv[1], "-h")) gxattr_usage(EXIT_SUCCESS);
    else if (!strcmp(argv[1], "-L")) {
        gxattr_list(argv[2]);
    }
    else if (!strcmp(argv[1], "-G")) {
        gxattr_get(argv[3], argv[2]);
    }
    else if (!strcmp(argv[1], "-S")) {
        gxattr_set(argv[4], argv[2], argv[3]);
    }
    else
	   gxattr_usage(EXIT_FAILURE);
	return 0;
}

