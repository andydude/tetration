#include "gxattr.h"

void gxattr_list_ex(
    const char *path, 
    int options)
{
	char *name;
	char name_buffer[CHX_NAME_BUFFER_SIZE];
	int name_depth, name_len, ret_size;

    ret_size = listxattr(path, name_buffer, CHX_NAME_BUFFER_SIZE
#if kDarwin
, options
#endif
);
	//printf(" %d\n", ret_size);
    name = name_buffer;
    name_len = (int)strlen(name) + 1;
    name_depth = (int)name - (int)name_buffer;
    while (strlen(name)) {
        gxattr_get(path, name);
        name += name_len;
        name_len = (int)strlen(name) + 1;
        name_depth = (int)name - (int)name_buffer;
        if (name_depth >= ret_size) break;
    }
}

void gxattr_list(const char *path)
{
    gxattr_list_ex(path, 0);
}

void gxattr_get_ex(
    const char *path, 
    const char *name, 
    int options)
{   
    int ret_size;
    char value_buffer[CHX_VALUE_BUFFER_SIZE];
    char *value;

    ret_size = getxattr(path, name, value_buffer, 
        CHX_VALUE_BUFFER_SIZE
#if kDarwin
, options
#endif
);
	//printf(" %d\n", ret_size);
    value = (char *)malloc(sizeof(char)*(ret_size+2));
    strncpy(value, value_buffer, (int)ret_size);
    printf("'%s'='%s'\n", name, value);
}

void gxattr_get(const char *path, const char *name)
{
    gxattr_get_ex(path, name, 0);
}


void gxattr_set_ex(
    const char *path, 
    const char *name, 
    void *value, 
    int size,
    int options)
{
    char value_buffer[CHX_VALUE_BUFFER_SIZE];
    int ret_size;

    ret_size = setxattr(path, name, value, size, 0
#if kDarwin
, options
#endif
);
	printf(" %d\n", ret_size);
    printf("'%s'='%s'\n", name, value);
}

void gxattr_set(const char *path, const char *name, const char *value)
{
    gxattr_set_ex(path, name, (void *)value, (int)strlen(value), 0);
}
