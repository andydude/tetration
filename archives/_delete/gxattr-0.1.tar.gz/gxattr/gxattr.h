#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/xattr.h>
#include <stdio.h>
#include <sys/sysctl.h>

#ifdef _SYS_SYSCTL_H
#define kDarwin 0
#define kLinux 1
#endif
#ifdef _SYS_SYSCTL_H_
#include <AvailabilityMacros.h>
#ifdef MAC_OS_X_VERSION_10_3
#define kDarwin 1
#define kLinux 0
#endif
#endif


/*
ssize_t getxattr(
	const char *path, 
	const char *name, 
	void *value, 
	size_t size, 
	u_int32_t position, 
	int options)

ssize_t fgetxattr(
	int fd, 
	const char *name, 
	void *value, 
	size_t size, 
	u_int32_t$

int setxattr(
	const char *path, 
	const char *name, 
	const void *value, 
	size_t size
	u_int32_t position, 
	int options

int fsetxattr(int fd, 
	const char *name, 
	const void *value, 
	size_t size, u_int32$
int removexattr(const char *path, const char *name, int options);
int fremovexattr(int fd, const char *name, int options);
ssize_t listxattr(const char *path, char *namebuff, size_t size, int options);
ssize_t flistxattr(int fd, char *namebuff, size_t size, int options);
*/

#define CHX_NAME_BUFFER_SIZE (1<<8)
#define CHX_VALUE_BUFFER_SIZE (1<<16)

void gxattr_list_ex(const char *path, int options);
void gxattr_list(const char *path);
void gxattr_get_ex(const char *path, const char *name, int options);
void gxattr_get(const char *path, const char *name);
void gxattr_set_ex(const char *path, const char *name, void *value, 
    int size, int options);
void gxattr_set(const char *path, const char *name, const char *value);
